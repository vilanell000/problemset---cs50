#include <cs50.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

bool onlydigit(string s);
char rotate(char c, int n);

int main(int argc, string argv[])
{
    // make sure run with only one command-line
    if (argc != 2)
    {
        printf("Usage: ./caesar key\n");
        return 1;
    }

    string key = argv[1];
    if (!onlydigit(key))
    {
        printf("Usage: ./caesar key\n");
        return 1;
    }

    // prompt user for plaintext
    string plaint = get_string("plaintext: ");

    // For each character in the plaintext:
    int k = atoi(key);
    char cipher[strlen(plaint) + 1];

    for (int i = 0, n = strlen(plaint); i < n; i++)
    {
        cipher[i] = rotate(plaint[i], k);
    }

    cipher[strlen(plaint)] = '\0';
    printf("ciphertext: %s\n", cipher);
}

// make sure char in argv[1] is a digit
bool onlydigit(string s)
{
    for (int i = 0, n = strlen(s); i < n; i++)
    {
        if (!isdigit(s[i]))
        {
            return false;
        }
    }
    return true;
}

// convert argv[1] to int
char rotate(char c, int n)
{
    if (c >= 'a' && c <= 'z')
    {
        return 'a' + (c - 'a' + n) % 26;
    }
    else if (c >= 'A' && c <= 'Z')
    {
        return 'A' + (c - 'A' + n) % 26;
    }
    else
    {
        return c;
    }
}
