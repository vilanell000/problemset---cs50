#include "helpers.h"
#include <math.h>

// Convert image to grayscale
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{
    // loop over all pixels
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            // take average of red,blue and green
            // update
            int avergb =
                round((image[i][j].rgbtRed + image[i][j].rgbtGreen + image[i][j].rgbtBlue) / 3.0);
            image[i][j].rgbtRed = image[i][j].rgbtGreen = image[i][j].rgbtBlue = avergb;
        }
    }
    return;
}

// Convert image to sepia
void sepia(int height, int width, RGBTRIPLE image[height][width])
{
    // loop over all pixels
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            // compute sepia values
            int sepiaR = round(.393 * image[i][j].rgbtRed + .769 * image[i][j].rgbtGreen +
                               .189 * image[i][j].rgbtBlue);
            int sepiaG = round(.349 * image[i][j].rgbtRed + .686 * image[i][j].rgbtGreen +
                               .168 * image[i][j].rgbtBlue);
            int sepiaB = round(.272 * image[i][j].rgbtRed + .534 * image[i][j].rgbtGreen +
                               .131 * image[i][j].rgbtBlue);

            // update
            image[i][j].rgbtRed = sepiaR > 255 ? 255 : sepiaR;
            image[i][j].rgbtGreen = sepiaG > 255 ? 255 : sepiaG;
            image[i][j].rgbtBlue = sepiaB > 255 ? 255 : sepiaB;
        }
    }
    return;
}

// Reflect image horizontally
void reflect(int height, int width, RGBTRIPLE image[height][width])
{
    // loop over all pixels
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width / 2; j++)
        {
            // swap pixels
            RGBTRIPLE temp = image[i][j];
            image[i][j] = image[i][width - 1 - j];
            image[i][width - 1 - j] = temp;
        }
    }
    return;
}

// Blur image
void blur(int height, int width, RGBTRIPLE image[height][width])
{
    // Create a copy of image
    RGBTRIPLE copy[height][width];

    // loop all pixels
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            // reset color values
            double blurR = 0, blurG = 0, blurB = 0, counts = 0;

            // loop affected pixels
            for (int row = 1; row >= -1; row--)
            {
                for (int col = 1; col >= -1; col--)
                {
                    if (row + i < 0 || row + i > height - 1)
                    {
                        continue;
                    }
                    if (col + j < 0 || col + j > width - 1)
                    {
                        continue;
                    }
                    // add pixels and color values
                    counts++;
                    blurR += image[i + row][j + col].rgbtRed;
                    blurG += image[i + row][j + col].rgbtGreen;
                    blurB += image[i + row][j + col].rgbtBlue;
                }
            }
            // average the original color values
            copy[i][j].rgbtRed = round(blurR / counts);
            copy[i][j].rgbtGreen = round(blurG / counts);
            copy[i][j].rgbtBlue = round(blurB / counts);
        }
    }
    // copy
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            image[i][j] = copy[i][j];
        }
    }
}
