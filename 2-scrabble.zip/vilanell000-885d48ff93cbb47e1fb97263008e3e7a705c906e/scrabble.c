#include <cs50.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>

int main()
{
    // get string form 2 users
    string word1 = get_string("Player 1: ");
    string word2 = get_string("Player 2: ");

    // convert character to uppercase
    for (int i = 0, len = strlen(word1); i < len; i++)
    {
        word1[i] = toupper(word1[i]);
    }

    for (int i = 0, len = strlen(word2); i < len; i++)
    {
        word2[i] = toupper(word2[i]);
    }

    // compute their score
    // get each char in thier string
    // link char to their score

    int points[] = {1, 3, 3, 2, 1, 4, 2, 4, 1, 8, 5, 1, 3, 1, 1, 3, 10, 1, 1, 1, 1, 4, 4, 8, 4, 10};
    int score1 = 0;
    int score2 = 0;

    // add the score of char

    for (int i = 0, len = strlen(word1); i < len; i++)
    {
        score1 += points[word1[i] - 'A'];
    }

    for (int i = 0, len = strlen(word2); i < len; i++)
    {
        score2 += points[word2[i] - 'A'];
    }
    // print the winner
    if (score1 > score2)
    {
        printf("Player 1 wins! \n");
    }
    else if (score1 < score2)
    {
        printf("Player 2 wins! \n");
    }
    else
    {
        printf("Tie! \n");
    }
}
