from cs50 import get_float

while True:
    i = get_float("Change: ")
    if i > 0:
        break

cents = round(i * 100)

quarters = (cents // 25)
cents %= 25

dimes = cents // 10
cents %= 10

nickels = cents // 5
cents %= 5

pennies = cents // 1

print(quarters + dimes + nickels + pennies)
