-- Keep a log of any SQL queries you execute as you solve the mystery.
-- check the crime scene description on July 28,2023
SELECT description
FROM crime_scene_reports
WHERE month = 7 AND day = 28
AND street = 'Humphrey Street';

-- check interviews on that day
SELECT name, transcript FROM interviews
WHERE year = 2023 AND month = 7 AND day = 28;

-- find out people withdraw money at the morning
    -- check the atm to get account number
    -- using acount number find the person id and name of these bank account
SELECT person_id, name FROM bank_accounts
JOIN people ON bank_accounts.person_id = people.id
WHERE account_number IN
    (SELECT account_number FROM atm_transactions
      WHERE year = 2023 AND month = 7 AND day = 28
      AND atm_location = 'Leggett Street'
      AND transaction_type = 'withdraw');

-- loof for cars and licenses left the parking lot within 10 minutes
SELECT activity, bakery_security_logs.license_plate, people.name
FROM bakery_security_logs
JOIN people ON people.license_plate= bakery_security_logs.license_plate
WHERE year = 2023 AND month = 7 AND day = 28
AND hour = 10 AND minute BETWEEN 15 AND 26;

-- compare these two name list, find conmmon points:
    -- Bruce,686048,Diana 514354,Luca 467400 in suspects

-- receiver and caller of the phone call after leaving
SELECT receiver, caller, people.name, people.id
FROM phone_calls
JOIN people ON phone_calls.caller = people.phone_number
WHERE year = 2023 AND month = 7 AND day = 28 AND duration < 60;
    -- got Bruce，id686048，(367)555-5533 call (375)555-8161； Diana 514354，(770)555-1861,call(725)555-3243

-- find out the person Bruce called
SELECT name, phone_number FROM people WHERE phone_number IN('(375)555-8161', '(725)555-3243');
    -- got Robin

-- check passengers on the earliest flight on July 29
SELECT passengers.flight_id, flights.hour, flights.destination_airport_id, people.id, people.name
FROM flights
JOIN airports ON flights.origin_airport_id = airports.id
JOIN passengers ON flights.id = passengers.flight_id
JOIN people ON passengers.passport_number = people.passport_number
WHERE flights.year = 2023 AND flights.month = 7 AND flights.day = 29
AND airports.full_name LIKE '%Fiftyville%'
ORDER BY flights.hour, flights.minute
LIMIT 10;
    -- got Bruce,Luca in suspects

--check the destination with id = 4
SELECT full_name
FROM airports
JOIN flights ON airports.id = flights.destination_airport_id
WHERE destination_airport_id = 4;
    