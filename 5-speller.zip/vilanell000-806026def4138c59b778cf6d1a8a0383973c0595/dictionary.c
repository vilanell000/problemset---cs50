// Implements a dictionary's functionality

#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <stdlib.h>

#include "dictionary.h"

// Represents a node in a hash table
typedef struct node
{
    char word[LENGTH + 1];
    struct node *next;
} node;

// TODO: Choose number of buckets in hash table
const unsigned int N = 26;

// Hash table
node *table[N];

// Returns true if word is in dictionary, else false
bool check(const char *word)
{
    // obtain hash value
    int checkvalue = hash(word);
    // search the hash table
    node *cnode = table[checkvalue];
    // iterate hash table
    while(cnode != NULL)
    {
        // compare hash value and word
        if(strcasecmp(cnode->word, word) == 0)
        {
            return true;
        }
        cnode = cnode->next;
    }
    return false;
}

// Hashes word to a number
unsigned int hash(const char *word)
{
    int hashvalue = 0;
    int i = 0;
    // iterate each letter
    while(word[i] != '\0')
    {
        char c = toupper(word[i]);
        hashvalue = (c + hashvalue * 31) % N;
        i++;
    }
    return hashvalue;
}
// declare variable to store number of words loaded
int wordcount = 0;

// Loads dictionary into memory, returning true if successful, else false
bool load(const char *dictionary)
{
        // open dictionary file
        FILE *source = fopen(dictionary, "r");
        if(source == NULL)
        {
            return false;
        }

        // read each word
        char word[LENGTH + 1];
        while(fscanf(source, "%s", word) != EOF)
        {
            // add words to hash table
            // a new hash table node
            node *n = malloc(sizeof(node));
            if(n == NULL)
            {
                return 1;
            }
            // copy the word into the new node
            strcpy(n->word, word);

            // insert the new node into hash table
            // determine which linked list
            int hashn = hash(word);
            n->next = table[hashn];
            table[hashn] = n;

            // count when each word loaded
            wordcount++;
        }

        // close file
        fclose(source);
        return true;
}

// Returns number of words in dictionary if loaded, else 0 if not yet loaded
unsigned int size(void)
{
    return wordcount;
}

// Unloads dictionary from memory, returning true if successful, else false
bool unload(void)
{
    // iterate every hash table bucket
    for(int i = 0; i < N; i++)
    {
        node *cursor = table[i];
        while(cursor != NULL)
        {
            // save current node before free
            node *temp = cursor;
            cursor = cursor->next;
            free(temp);
        }
     }

    return true;
}
