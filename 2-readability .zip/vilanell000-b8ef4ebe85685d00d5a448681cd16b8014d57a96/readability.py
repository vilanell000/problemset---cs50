from cs50 import get_string

# get input
text = get_string("Text: ")

letters = 0
words = 1
sent = 0
# count letters
for i in text:
    if i.isalpha() == True:
        letters += 1
# count words(spaces)
    elif i.isspace() == True:
        words += 1
# count sentences
    elif i == "!" or i == "." or i == "?":
        sent += 1

# compute index
L = letters / words * 100
S = sent / words * 100
index = round(0.0588 * L - 0.296 * S - 15.8)

# print grade
if index >= 16:
    print("Grade 16+")
elif index < 1:
    print("Before Grade 1")
else:
    print(f"Grade {index}")
