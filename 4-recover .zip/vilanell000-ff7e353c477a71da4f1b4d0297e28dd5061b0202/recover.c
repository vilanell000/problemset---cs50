#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
int main(int argc, char *argv[])
{
    // only accept one command-line argument
    if (argc != 2)
    {
        printf("usage:/recover FILE\n");
        return 1;
    }

    // open memory card
    FILE *card = fopen(argv[1], "r");

    // inform users if cannot open
    if (!card)
    {
        printf("Cannot open the file");
        return 1;
    }

    // read until no data left and create new file
    uint8_t buffer[512];
    int counter = 0;
    FILE *img = NULL;

    while (fread(buffer, 1, 512, card) == 512)
    {
        // if start of new jpeg firt 4 bytes
        if (buffer[0] == 0xff && buffer[1] == 0xd8 && buffer[2] == 0xff &&
            (buffer[3] & 0xf0) == 0xe0)
        {
            // close previous jpeg if it opened
            if (img != NULL)
            {
                fclose(img);
            }
            // create new file with three-digit decimal number
            char filename[8];
            sprintf(filename, "%03i.jpg", counter++);
            img = fopen(filename, "w");
            if (!img)
            {
                perror("Cannot create the file");
                fclose(card);
                return 1;
            }
        }
        if (img != NULL)
        {
            fwrite(buffer, 1, 512, img);
        }
    }

    // close the file written to
    if (img != NULL)
    {
        fclose(img);
    }
    fclose(card);
    return 0;
}
