--name of people in the movie
    -- the stars.movie_id belongs to Kevin
    -- the id of people name Kevin Bacon and birth 1958
SELECT name FROM people p1
JOIN stars s1 ON p1.id = s1.person_id
WHERE s1.movie_id IN
(SELECT movie_id FROM stars, people
WHERE stars.person_id = people.id
AND people.name= 'Kevin Bacon'
AND people.birth = 1958)
AND p1.name <> 'Kevin Bacon';
