#include <cs50.h>
#include <math.h>
#include <stdio.h>

int main(void)
{
    // get the money
    int i;
    do
    {
        i = get_int("Change owed: ");
    }
    while (i <= 0);
    // compute the change
    // how many quarters
    int quarters = i / 25;
    // how many dimes
    int dimes = (i - 25 * quarters) / 10;
    // how many nickels
    int nickels = (i - 25 * quarters - 10 * dimes) / 5;
    // how many pennies
    int pennies = (i - 25 * quarters - 10 * dimes - 5 * nickels) / 1;
    // print the sum
    printf("%i ", (quarters + dimes + nickels + pennies));
}
