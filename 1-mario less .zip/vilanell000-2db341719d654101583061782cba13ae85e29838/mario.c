#include <stdio.h>
#include <cs50.h>
#include <ctype.h>

void printrow(int brick);
int main(void)
{
    // prompt the user for the height
    int h;

    do
    {
        h = get_int("Height: ");
    }
    while (h < 1 || h > 8);

    // print the pyramid
    // print the height of the pyramid
    for (int i = 0; i < h; i++)
    {
        // print space
        for (int j = h - i - 1; j > 0; j--)
        {
            printf(" ");
        }
        // print hashes
        printrow(i + 1);

        // print a new line
        printf("\n");
    }
}

void printrow(int brick)
{
    for (int i = 0; i < brick; i++)
    {
        printf("#");
    }
}
